// RestoreVSS.cpp - Fast blocked C++ implementation to copy data from VSS Snapshot
// Optimized for high-performance disk-to-disk copying with overlapped I/O
// Build: cl /EHsc /O2 /std:c++17 RestoreVSS.cpp

#define NOMINMAX  // Prevent Windows.h from defining min/max macros
#include <windows.h>
#include <cstdio>
#include <string>
#include <vector>
#include <memory>
#include <algorithm>
#include <chrono>

// Performance statistics
struct PerfStats {
    ULONGLONG bytesCopied = 0;
    ULONGLONG bytesRead = 0;
    ULONGLONG bytesWritten = 0;
    DWORD readOps = 0;
    DWORD writeOps = 0;
    std::chrono::high_resolution_clock::time_point startTime;
    std::chrono::high_resolution_clock::time_point lastUpdate;
    
    void Start() {
        startTime = std::chrono::high_resolution_clock::now();
        lastUpdate = startTime;
    }
    
    double GetElapsedSeconds() const {
        auto now = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(now - startTime);
        return duration.count() / 1000.0;
    }
    
    double GetThroughputMBps() const {
        double elapsed = GetElapsedSeconds();
        if (elapsed < 0.001) return 0.0;
        return (bytesCopied / (1024.0 * 1024.0)) / elapsed;
    }
};

// Alignment information for device I/O
struct AlignInfo {
    DWORD logicalSector = 512;
    DWORD physicalSector = 4096;
    DWORD alignment = 4096;  // Optimal alignment for modern SSDs
};

// Buffer structure for overlapped I/O
struct IoBuffer {
    void* data = nullptr;
    SIZE_T size = 0;
    OVERLAPPED overlapped = {};
    ULONGLONG offset = 0;
    bool isRead = false;
    bool isPending = false;
    DWORD bytesTransferred = 0;
    
    ~IoBuffer() {
        if (data) {
            VirtualFree(data, 0, MEM_RELEASE);
        }
    }
};

// Get device length
bool GetDeviceLength(HANDLE h, ULONGLONG& length) {
    GET_LENGTH_INFORMATION info{};
    DWORD bytes = 0;
    if (!DeviceIoControl(h, IOCTL_DISK_GET_LENGTH_INFO, nullptr, 0,
        &info, sizeof(info), &bytes, nullptr)) {
        return false;
    }
    length = info.Length.QuadPart;
    return true;
}

// Get device alignment information
bool GetAlignment(HANDLE h, AlignInfo& align) {
    // Get logical sector size
    DISK_GEOMETRY_EX geo{};
    DWORD bytes = 0;
    if (DeviceIoControl(h, IOCTL_DISK_GET_DRIVE_GEOMETRY_EX, nullptr, 0,
        &geo, sizeof(geo), &bytes, nullptr)) {
        align.logicalSector = geo.Geometry.BytesPerSector;
    }
    
    // Get physical sector size and alignment
    STORAGE_PROPERTY_QUERY query{};
    query.PropertyId = StorageAccessAlignmentProperty;
    query.QueryType = PropertyStandardQuery;
    BYTE buffer[512]{};
    
    if (DeviceIoControl(h, IOCTL_STORAGE_QUERY_PROPERTY, &query, sizeof(query),
        buffer, sizeof(buffer), &bytes, nullptr)) {
        auto* alignDesc = reinterpret_cast<STORAGE_ACCESS_ALIGNMENT_DESCRIPTOR*>(buffer);
        if (alignDesc->BytesPerLogicalSector) {
            align.logicalSector = alignDesc->BytesPerLogicalSector;
        }
        if (alignDesc->BytesPerPhysicalSector) {
            align.physicalSector = alignDesc->BytesPerPhysicalSector;
        }
        if (alignDesc->BytesOffsetForSectorAlignment) {
            align.alignment = alignDesc->BytesOffsetForSectorAlignment;
        }
    }
    
    // Ensure sane defaults
    if (align.logicalSector == 0) align.logicalSector = 512;
    if (align.physicalSector == 0) align.physicalSector = align.logicalSector;
    if (align.alignment == 0) align.alignment = align.physicalSector;
    
    // Round up to at least 4KB for modern SSDs
    if (align.alignment < 4096) align.alignment = 4096;
    
    return true;
}

// Allocate aligned buffer for device I/O
void* AllocAligned(SIZE_T size, DWORD alignment) {
    // VirtualAlloc is page-aligned (4KB), which is sufficient for most cases
    // But we ensure it's at least aligned to the requested alignment
    SIZE_T allocSize = size;
    if (allocSize % alignment != 0) {
        allocSize = ((allocSize + alignment - 1) / alignment) * alignment;
    }
    
    void* ptr = VirtualAlloc(nullptr, allocSize, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
    if (!ptr) return nullptr;
    
    // Verify alignment (should always be true for VirtualAlloc)
    if (reinterpret_cast<ULONG_PTR>(ptr) % alignment != 0) {
        VirtualFree(ptr, 0, MEM_RELEASE);
        return nullptr;
    }
    
    return ptr;
}

// Parse size string (e.g., "8M", "16K", "1G")
SIZE_T ParseSize(const std::wstring& str) {
    if (str.empty()) return 0;
    
    SIZE_T multiplier = 1;
    std::wstring numStr = str;
    
    wchar_t lastChar = towupper(str.back());
    if (lastChar == L'K') {
        multiplier = 1024;
        numStr = str.substr(0, str.length() - 1);
    } else if (lastChar == L'M') {
        multiplier = 1024 * 1024;
        numStr = str.substr(0, str.length() - 1);
    } else if (lastChar == L'G') {
        multiplier = 1024ull * 1024ull * 1024ull;
        numStr = str.substr(0, str.length() - 1);
    }
    
    SIZE_T value = _wtoi(numStr.c_str());
    return value * multiplier;
}

// Format bytes to human-readable string
std::wstring FormatBytes(ULONGLONG bytes) {
    const wchar_t* units[] = { L"B", L"KB", L"MB", L"GB", L"TB" };
    int unit = 0;
    double size = static_cast<double>(bytes);
    
    while (size >= 1024.0 && unit < 4) {
        size /= 1024.0;
        unit++;
    }
    
    wchar_t buf[64];
    swprintf_s(buf, L"%.2f %s", size, units[unit]);
    return buf;
}

// Print progress with statistics
void PrintProgress(const PerfStats& stats, ULONGLONG totalBytes) {
    double elapsed = stats.GetElapsedSeconds();
    double throughput = stats.GetThroughputMBps();
    double percent = totalBytes > 0 ? (stats.bytesCopied * 100.0 / totalBytes) : 0.0;
    
    wprintf(L"\rProgress: %6.2f%% | Copied: %12ls | Speed: %8.2f MB/s | Time: %6.1f s",
        percent, FormatBytes(stats.bytesCopied).c_str(), throughput, elapsed);
}

// Sequential copy (fallback when overlapped I/O is not available)
bool SequentialCopy(HANDLE hSrc, HANDLE hDst, ULONGLONG totalBytes, SIZE_T blockSize,
    DWORD sectorSize, PerfStats& stats) {
    
    void* buffer = AllocAligned(blockSize, sectorSize);
    if (!buffer) {
        wprintf(L"Failed to allocate buffer\n");
        return false;
    }
    
    ULONGLONG offset = 0;
    stats.Start();
    
    while (offset < totalBytes) {
        DWORD toRead = static_cast<DWORD>(std::min<ULONGLONG>(blockSize, totalBytes - offset));
        DWORD bytesRead = 0;
        DWORD bytesWritten = 0;
        
        LARGE_INTEGER liOffset{};
        liOffset.QuadPart = offset;
        
        // Read from source
        if (SetFilePointerEx(hSrc, liOffset, nullptr, FILE_BEGIN) == 0) {
            wprintf(L"\nSetFilePointerEx failed at offset %llu (err=%lu)\n", offset, GetLastError());
            VirtualFree(buffer, 0, MEM_RELEASE);
            return false;
        }
        
        if (!ReadFile(hSrc, buffer, toRead, &bytesRead, nullptr)) {
            wprintf(L"\nReadFile failed at offset %llu (err=%lu)\n", offset, GetLastError());
            VirtualFree(buffer, 0, MEM_RELEASE);
            return false;
        }
        
        if (bytesRead != toRead) {
            wprintf(L"\nShort read: got %lu bytes, expected %lu\n", bytesRead, toRead);
            VirtualFree(buffer, 0, MEM_RELEASE);
            return false;
        }
        
        stats.bytesRead += bytesRead;
        stats.readOps++;
        
        // Write to destination
        if (SetFilePointerEx(hDst, liOffset, nullptr, FILE_BEGIN) == 0) {
            wprintf(L"\nSetFilePointerEx failed at offset %llu (err=%lu)\n", offset, GetLastError());
            VirtualFree(buffer, 0, MEM_RELEASE);
            return false;
        }
        
        if (!WriteFile(hDst, buffer, toRead, &bytesWritten, nullptr)) {
            wprintf(L"\nWriteFile failed at offset %llu (err=%lu)\n", offset, GetLastError());
            VirtualFree(buffer, 0, MEM_RELEASE);
            return false;
        }
        
        if (bytesWritten != toRead) {
            wprintf(L"\nShort write: wrote %lu bytes, expected %lu\n", bytesWritten, toRead);
            VirtualFree(buffer, 0, MEM_RELEASE);
            return false;
        }
        
        stats.bytesWritten += bytesWritten;
        stats.writeOps++;
        stats.bytesCopied += bytesWritten;
        offset += bytesWritten;
        
        // Update progress every 64MB
        if ((offset % (64ull * 1024 * 1024)) == 0) {
            PrintProgress(stats, totalBytes);
        }
    }
    
    VirtualFree(buffer, 0, MEM_RELEASE);
    return true;
}

// Overlapped I/O copy with multiple buffers (queue depth)
// Uses a simpler approach: single buffer pool with state tracking
bool OverlappedCopy(HANDLE hSrc, HANDLE hDst, ULONGLONG totalBytes, SIZE_T blockSize,
    DWORD sectorSize, DWORD queueDepth, PerfStats& stats) {
    
    // Create buffer pool (need queueDepth buffers for pipelining)
    std::vector<std::unique_ptr<IoBuffer>> buffers;
    buffers.reserve(queueDepth);
    
    for (DWORD i = 0; i < queueDepth; ++i) {
        auto buf = std::make_unique<IoBuffer>();
        buf->size = blockSize;
        buf->data = AllocAligned(blockSize, sectorSize);
        if (!buf->data) {
            wprintf(L"Failed to allocate buffer %u\n", i);
            return false;
        }
        memset(&buf->overlapped, 0, sizeof(OVERLAPPED));
        buf->isPending = false;
        buffers.push_back(std::move(buf));
    }
    
    stats.Start();
    ULONGLONG nextReadOffset = 0;
    ULONGLONG nextWriteOffset = 0;
    ULONGLONG completedWrites = 0;
    
    // Initialize: start all reads
    for (DWORD i = 0; i < queueDepth && nextReadOffset < totalBytes; ++i) {
        auto& buf = buffers[i];
        DWORD toRead = static_cast<DWORD>(std::min<ULONGLONG>(blockSize, totalBytes - nextReadOffset));
        buf->offset = nextReadOffset;
        buf->isRead = true;
        buf->isPending = true;
        
        buf->overlapped.Offset = static_cast<DWORD>(nextReadOffset);
        buf->overlapped.OffsetHigh = static_cast<DWORD>(nextReadOffset >> 32);
        
        DWORD bytesRead = 0;
        if (!ReadFile(hSrc, buf->data, toRead, &bytesRead, &buf->overlapped)) {
            DWORD err = GetLastError();
            if (err != ERROR_IO_PENDING) {
                wprintf(L"\nReadFile failed at offset %llu (err=%lu)\n", nextReadOffset, err);
                return false;
            }
        } else {
            // Completed immediately
            buf->bytesTransferred = bytesRead;
            buf->isPending = false;
        }
        nextReadOffset += toRead;
    }
    
    // Main I/O loop: pipeline reads and writes
    while (completedWrites < totalBytes) {
        bool madeProgress = false;
        
        // Check for completed reads and start writes (in order)
        for (DWORD i = 0; i < queueDepth; ++i) {
            auto& buf = buffers[i];
            
            // If this is a completed read ready to write (must be in order)
            if (buf->isRead && !buf->isPending && buf->offset == nextWriteOffset) {
                // Start write operation
                buf->isRead = false;
                buf->isPending = true;
                buf->overlapped.Offset = static_cast<DWORD>(buf->offset);
                buf->overlapped.OffsetHigh = static_cast<DWORD>(buf->offset >> 32);
                
                DWORD bytesWritten = 0;
                if (!WriteFile(hDst, buf->data, buf->bytesTransferred, &bytesWritten, &buf->overlapped)) {
                    DWORD err = GetLastError();
                    if (err != ERROR_IO_PENDING) {
                        wprintf(L"\nWriteFile failed at offset %llu (err=%lu)\n", buf->offset, err);
                        return false;
                    }
                } else {
                    // Completed immediately
                    buf->bytesTransferred = bytesWritten;
                    buf->isPending = false;
                }
                madeProgress = true;
            }
        }
        
        // Check for completed operations
        for (DWORD i = 0; i < queueDepth; ++i) {
            auto& buf = buffers[i];
            
            // Check if read completed
            if (buf->isRead && buf->isPending) {
                DWORD bytesTransferred = 0;
                if (GetOverlappedResult(hSrc, &buf->overlapped, &bytesTransferred, FALSE)) {
                    buf->bytesTransferred = bytesTransferred;
                    buf->isPending = false;
                    stats.bytesRead += bytesTransferred;
                    stats.readOps++;
                    madeProgress = true;
                } else {
                    DWORD err = GetLastError();
                    if (err != ERROR_IO_PENDING) {
                        wprintf(L"\nGetOverlappedResult failed for read (err=%lu)\n", err);
                        return false;
                    }
                }
            }
            // Check if write completed
            else if (!buf->isRead && buf->isPending) {
                DWORD bytesTransferred = 0;
                if (GetOverlappedResult(hDst, &buf->overlapped, &bytesTransferred, FALSE)) {
                    buf->bytesTransferred = bytesTransferred;
                    buf->isPending = false;
                    stats.bytesWritten += bytesTransferred;
                    stats.writeOps++;
                    stats.bytesCopied += bytesTransferred;
                    completedWrites += bytesTransferred;
                    nextWriteOffset += bytesTransferred;
                    
                    // Update progress every 64MB
                    if ((completedWrites % (64ull * 1024 * 1024)) == 0) {
                        PrintProgress(stats, totalBytes);
                    }
                    
                    // Buffer is now free, start next read
                    if (nextReadOffset < totalBytes) {
                        DWORD toRead = static_cast<DWORD>(std::min<ULONGLONG>(blockSize, totalBytes - nextReadOffset));
                        buf->offset = nextReadOffset;
                        buf->isRead = true;
                        buf->isPending = true;
                        
                        buf->overlapped.Offset = static_cast<DWORD>(nextReadOffset);
                        buf->overlapped.OffsetHigh = static_cast<DWORD>(nextReadOffset >> 32);
                        
                        DWORD bytesRead = 0;
                        if (!ReadFile(hSrc, buf->data, toRead, &bytesRead, &buf->overlapped)) {
                            DWORD err = GetLastError();
                            if (err != ERROR_IO_PENDING) {
                                wprintf(L"\nReadFile failed at offset %llu (err=%lu)\n", nextReadOffset, err);
                                return false;
                            }
                        } else {
                            buf->bytesTransferred = bytesRead;
                            buf->isPending = false;
                        }
                        nextReadOffset += toRead;
                    }
                    madeProgress = true;
                } else {
                    DWORD err = GetLastError();
                    if (err != ERROR_IO_PENDING) {
                        wprintf(L"\nGetOverlappedResult failed for write (err=%lu)\n", err);
                        return false;
                    }
                }
            }
        }
        
        // If no progress was made, yield CPU
        if (!madeProgress) {
            Sleep(0);  // Yield to other threads
        }
    }
    
    // Wait for all pending operations to complete
    for (auto& buf : buffers) {
        if (buf->isPending) {
            if (buf->isRead) {
                GetOverlappedResult(hSrc, &buf->overlapped, &buf->bytesTransferred, TRUE);
            } else {
                GetOverlappedResult(hDst, &buf->overlapped, &buf->bytesTransferred, TRUE);
            }
        }
    }
    
    return true;
}

int wmain(int argc, wchar_t** argv) {
    // Parse command line arguments
    std::wstring shadowPath, targetPath;
    SIZE_T blockSize = 8ull * 1024 * 1024;  // Default 8 MiB
    DWORD queueDepth = 4;  // Default queue depth
    bool useOverlapped = true;
    bool verbose = false;
    
    if (argc < 3) {
        wprintf(L"RestoreVSS - Fast VSS Snapshot Restore Utility\n");
        wprintf(L"Usage: RestoreVSS.exe --shadow <path> --target <path> [options]\n\n");
        wprintf(L"Options:\n");
        wprintf(L"  --shadow <path>     Shadow volume path (e.g., \\\\?\\GLOBALROOT\\Device\\HarddiskVolumeShadowCopy1)\n");
        wprintf(L"  --target <path>     Target partition path (e.g., \\\\.\\PhysicalDrive1)\n");
        wprintf(L"  --block <size>      Block size (default: 8M, suffixes: K/M/G)\n");
        wprintf(L"  --qdepth <n>        I/O queue depth for overlapped I/O (default: 4, max: 32)\n");
        wprintf(L"  --no-overlapped     Disable overlapped I/O (use sequential mode)\n");
        wprintf(L"  --verbose           Enable verbose output\n");
        wprintf(L"\nExample:\n");
        wprintf(L"  RestoreVSS.exe --shadow \\\\?\\GLOBALROOT\\Device\\HarddiskVolumeShadowCopy1 --target \\\\.\\PhysicalDrive1 --block 16M --qdepth 8\n");
        return 1;
    }
    
    for (int i = 1; i < argc; ++i) {
        std::wstring arg = argv[i];
        if (arg == L"--shadow" && i + 1 < argc) {
            shadowPath = argv[++i];
        } else if (arg == L"--target" && i + 1 < argc) {
            targetPath = argv[++i];
        } else if (arg == L"--block" && i + 1 < argc) {
            blockSize = ParseSize(argv[++i]);
            if (blockSize == 0) {
                wprintf(L"Invalid block size: %ls\n", argv[i]);
                return 1;
            }
        } else if (arg == L"--qdepth" && i + 1 < argc) {
            queueDepth = _wtoi(argv[++i]);
            if (queueDepth == 0 || queueDepth > 32) {
                wprintf(L"Invalid queue depth (must be 1-32): %ls\n", argv[i]);
                return 1;
            }
        } else if (arg == L"--no-overlapped") {
            useOverlapped = false;
        } else if (arg == L"--verbose") {
            verbose = true;
        }
    }
    
    if (shadowPath.empty() || targetPath.empty()) {
        wprintf(L"Error: --shadow and --target are required\n");
        return 1;
    }
    
    if (verbose) {
        wprintf(L"Shadow volume: %ls\n", shadowPath.c_str());
        wprintf(L"Target partition: %ls\n", targetPath.c_str());
        wprintf(L"Block size: %ls\n", FormatBytes(blockSize).c_str());
        wprintf(L"Queue depth: %u\n", queueDepth);
        wprintf(L"Overlapped I/O: %s\n", useOverlapped ? L"enabled" : L"disabled");
        wprintf(L"\n");
    }
    
    // Open source (shadow volume)
    HANDLE hSrc = CreateFileW(
        shadowPath.c_str(),
        GENERIC_READ,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        nullptr,
        OPEN_EXISTING,
        FILE_FLAG_NO_BUFFERING | FILE_FLAG_SEQUENTIAL_SCAN | (useOverlapped ? FILE_FLAG_OVERLAPPED : 0),
        nullptr
    );
    
    if (hSrc == INVALID_HANDLE_VALUE) {
        wprintf(L"Failed to open shadow volume: %ls (error %lu)\n", shadowPath.c_str(), GetLastError());
        return 2;
    }
    
    // Open destination (target partition)
    HANDLE hDst = CreateFileW(
        targetPath.c_str(),
        GENERIC_WRITE,
        FILE_SHARE_READ,
        nullptr,
        OPEN_EXISTING,
        FILE_FLAG_NO_BUFFERING | FILE_FLAG_SEQUENTIAL_SCAN | (useOverlapped ? FILE_FLAG_OVERLAPPED : 0),
        nullptr
    );
    
    if (hDst == INVALID_HANDLE_VALUE) {
        wprintf(L"Failed to open target partition: %ls (error %lu)\n", targetPath.c_str(), GetLastError());
        CloseHandle(hSrc);
        return 3;
    }
    
    // Get alignment information
    AlignInfo srcAlign{}, dstAlign{};
    if (!GetAlignment(hSrc, srcAlign) || !GetAlignment(hDst, dstAlign)) {
        wprintf(L"Warning: Failed to query device alignment, using defaults\n");
    }
    
    // Use the larger alignment requirement
    DWORD sectorSize = std::max(srcAlign.logicalSector, dstAlign.logicalSector);
    DWORD alignment = std::max(srcAlign.alignment, dstAlign.alignment);
    
    // Ensure block size is aligned
    if (blockSize % sectorSize != 0) {
        blockSize = ((blockSize + sectorSize - 1) / sectorSize) * sectorSize;
        if (verbose) {
            wprintf(L"Adjusted block size to %ls for sector alignment\n", FormatBytes(blockSize).c_str());
        }
    }
    
    if (verbose) {
        wprintf(L"Source logical sector: %u bytes, alignment: %u bytes\n", srcAlign.logicalSector, srcAlign.alignment);
        wprintf(L"Target logical sector: %u bytes, alignment: %u bytes\n", dstAlign.logicalSector, dstAlign.alignment);
        wprintf(L"Using sector size: %u bytes, alignment: %u bytes\n", sectorSize, alignment);
        wprintf(L"\n");
    }
    
    // Get device lengths
    ULONGLONG srcLen = 0, dstLen = 0;
    if (!GetDeviceLength(hSrc, srcLen) || !GetDeviceLength(hDst, dstLen)) {
        wprintf(L"Failed to query device lengths (error %lu)\n", GetLastError());
        CloseHandle(hSrc);
        CloseHandle(hDst);
        return 4;
    }
    
    if (dstLen < srcLen) {
        wprintf(L"Error: Target partition is smaller than source volume\n");
        wprintf(L"  Source: %ls\n", FormatBytes(srcLen).c_str());
        wprintf(L"  Target: %ls\n", FormatBytes(dstLen).c_str());
        CloseHandle(hSrc);
        CloseHandle(hDst);
        return 5;
    }
    
    if (verbose) {
        wprintf(L"Source size: %ls\n", FormatBytes(srcLen).c_str());
        wprintf(L"Target size: %ls\n", FormatBytes(dstLen).c_str());
        wprintf(L"\nStarting copy operation...\n");
    }
    
    // Perform the copy
    PerfStats stats;
    bool success = false;
    
    if (useOverlapped) {
        success = OverlappedCopy(hSrc, hDst, srcLen, blockSize, alignment, queueDepth, stats);
    } else {
        success = SequentialCopy(hSrc, hDst, srcLen, blockSize, alignment, stats);
    }
    
    if (!success) {
        wprintf(L"\nCopy operation failed\n");
        CloseHandle(hSrc);
        CloseHandle(hDst);
        return 6;
    }
    
    // Flush file buffers
    FlushFileBuffers(hDst);
    
    // Print final statistics
    double elapsed = stats.GetElapsedSeconds();
    double throughput = stats.GetThroughputMBps();
    
    wprintf(L"\n");
    wprintf(L"========================================\n");
    wprintf(L"Copy completed successfully!\n");
    wprintf(L"========================================\n");
    wprintf(L"Bytes copied:  %ls\n", FormatBytes(stats.bytesCopied).c_str());
    wprintf(L"Read operations:  %u\n", stats.readOps);
    wprintf(L"Write operations: %u\n", stats.writeOps);
    wprintf(L"Elapsed time:  %.2f seconds\n", elapsed);
    wprintf(L"Throughput:     %.2f MB/s\n", throughput);
    wprintf(L"========================================\n");
    
    CloseHandle(hSrc);
    CloseHandle(hDst);
    
    return 0;
}
